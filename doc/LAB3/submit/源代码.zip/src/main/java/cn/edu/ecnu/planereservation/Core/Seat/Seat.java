package cn.edu.ecnu.planereservation.Core.Seat;

/**
 * @author billchen
 * @version 1.0
 * @create 2020-12-22 11:36 下午
 **/
public class Seat {
}
