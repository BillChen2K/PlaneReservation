package cn.edu.ecnu.planereservation.Util;

import cn.edu.ecnu.planereservation.Model.UserModel;

/**
 * @author billchen
 * @version 1.0
 * @create 2020-12-19 03:21
 **/
public class Shared {
	public static UserModel currentUser = new UserModel();
}
