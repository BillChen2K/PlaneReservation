package cn.edu.ecnu.planereservation.Util;

/**
 * Constants used in the project
 *
 * @author billchen
 * @version 1.0
 * @create 2021-01-05 22:49
 **/
public class Const {
	public static final int RESERVATION_STATE_CANCELED = 0;
	public static final int RESERVATION_STATE_ACTIVE = 1;
}
